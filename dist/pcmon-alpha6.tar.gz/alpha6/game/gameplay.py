class Gameplay:
    def __init__(self) -> None:
        self.q = None
    
    def start(self):
        pass